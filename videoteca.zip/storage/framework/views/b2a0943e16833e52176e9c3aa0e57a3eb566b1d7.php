
<?php $__env->startSection('title'); ?>
Información de película
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Información de la película:</h1>
<h2><?php echo e($pelicula->nombre); ?> (<?php echo e($pelicula->anio); ?>)</h2>
<h3><?php echo e($pelicula->director); ?>. <?php echo e($pelicula->genero); ?></h3>
<h4>Sinopsis:</h4>
<p><?php echo e($pelicula->sinopsis); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\LaravelPeliculas\resources\views/peliculas/show.blade.php ENDPATH**/ ?>