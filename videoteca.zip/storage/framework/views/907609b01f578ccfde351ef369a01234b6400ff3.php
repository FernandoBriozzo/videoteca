
<?php $__env->startSection('title'); ?> Modificar Director <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="/generos/<?php echo e($genero->id); ?>">
    <input type="hidden" name="_method" value="PUT">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input class="form-control" type="text" name="nombre" id="nombre" value="<?php echo e($genero->nombre); ?>">
    </div>

    <div class="from-group">
        <button type="submit" class="btn btn-primary">Modificar</button>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Volver</a>
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\LaravelPeliculas\resources\views/generos/edit.blade.php ENDPATH**/ ?>