
<?php $__env->startSection('title'); ?> Modificar Película <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="/peliculas/<?php echo e($pelicula->id); ?>">
    <input type="hidden" name="_method" value="PUT">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input class="form-control" type="text" name="nombre" id="nombre" value="<?php echo e($pelicula->nombre); ?>">
    </div>
    <div class="form-group">
        <label for="anio">Año:</label>
        <input class="form-control" type="text" name="anio" id="anio" value="<?php echo e($pelicula->anio); ?>">
    </div>
    <div class="form-group">
        <label for="generos">Géneros:</label>
        <select class="form-control" id="genero" name="genero">
            <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($genero->id); ?>" <?php if($genero->id == $pelicula->genero_id): ?> selected <?php endif; ?>><?php echo e($genero->nombre); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="directores">Directores:</label>
        <select class="form-control" id="director" name="director">
            <?php $__currentLoopData = $directores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($director->id); ?>" <?php if($director->id == $pelicula->director_id): ?> selected <?php endif; ?>><?php echo e($director->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="from-group">
        <button type="submit" class="btn btn-primary">Modificar</button>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Volver</a>
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\LaravelPeliculas\resources\views/peliculas/edit.blade.php ENDPATH**/ ?>