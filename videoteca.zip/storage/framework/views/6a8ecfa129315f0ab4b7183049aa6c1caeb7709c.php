
<?php $__env->startSection('title'); ?> Crear Película <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="/peliculas">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input class="form-control" type="text" name="nombre" id="nombre">
    </div>
    <div class="form-group">
        <label for="anio">Año:</label>
        <input class="form-control" type="text" name="anio" id="anio">
    </div>
    <div class="form-group">
        <label for="generos">Géneros:</label>
        <select class="form-control" id="genero" name="genero">
            <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($genero->id); ?>"><?php echo e($genero->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="directores">Directores:</label>
        <select class="form-control" id="director" name="director">
            <?php $__currentLoopData = $directores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($director->id); ?>"><?php echo e($director->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="sinopsis">Sinopsis:</label>
        <input class="form-control" type="textarea" id="sinposis" name="sinopsis">
    </div>

    <div class="from-group">
        <button type="submit" class="btn btn-primary">Crear</button>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Volver</a>
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\LaravelPeliculas\resources\views/peliculas/create.blade.php ENDPATH**/ ?>