
<?php $__env->startSection('title'); ?> Películas por género <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Películas del género <?php echo e($genero->nombre); ?></h1>
<?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="/peliculas/<?php echo e($pelicula->id); ?>"><?php echo e($pelicula->nombre); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\LaravelPeliculas\resources\views/generos/show.blade.php ENDPATH**/ ?>