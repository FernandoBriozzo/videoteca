<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Director extends Model
{
    protected $fillable = ['nombre'];
}
